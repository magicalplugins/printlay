<?php
/**
 * PrintLay Product Meta Box
 *
 * Adds a meta box to WooCommerce products for enabling/linking PrintLay Designer.
 */

defined('ABSPATH') || exit;

class PrintLay_Product {

    private static ?self $instance = null;

    public static function instance(): self {
        if (self::$instance === null) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    private function __construct() {
        add_action('add_meta_boxes', [$this, 'add_meta_box']);
        add_action('save_post_product', [$this, 'save_meta'], 10, 2);
        add_action('wp_ajax_printlay_fetch_products', [$this, 'ajax_fetch_products']);
    }

    public function add_meta_box(): void {
        add_meta_box(
            'printlay_designer',
            __('PrintLay Designer', 'printlay-woocommerce'),
            [$this, 'render_meta_box'],
            'product',
            'side',
            'high'
        );
    }

    public function render_meta_box(\WP_Post $post): void {
        $enabled = get_post_meta($post->ID, '_printlay_enabled', true) === 'yes';
        $product_id = get_post_meta($post->ID, '_printlay_product_id', true);
        $from_price = get_post_meta($post->ID, '_printlay_from_price', true);
        $api_key = get_option('printlay_api_key', '');
        $host = get_option('printlay_host', 'https://printlay.co.uk');

        wp_nonce_field('printlay_save_meta', '_printlay_nonce');
        ?>
        <div id="printlay-meta-box">
            <?php if (empty($api_key)): ?>
                <p class="description" style="color:#dc3232;">
                    <?php esc_html_e('Please configure your API key in PrintLay > Settings first.', 'printlay-woocommerce'); ?>
                </p>
            <?php else: ?>
                <p>
                    <label>
                        <input type="checkbox" name="_printlay_enabled" value="yes" <?php checked($enabled); ?> />
                        <?php esc_html_e('Enable PrintLay Designer', 'printlay-woocommerce'); ?>
                    </label>
                </p>

                <div id="printlay-product-fields" style="<?php echo $enabled ? '' : 'display:none;'; ?>">
                    <p>
                        <label for="_printlay_product_id">
                            <strong><?php esc_html_e('Linked PrintLay Product', 'printlay-woocommerce'); ?></strong>
                        </label>
                    </p>
                    <p>
                        <select name="_printlay_product_id" id="_printlay_product_id" style="width:100%;">
                            <option value=""><?php esc_html_e('— Loading products...', 'printlay-woocommerce'); ?></option>
                        </select>
                    </p>
                    <p>
                        <label for="_printlay_from_price">
                            <strong><?php esc_html_e('"From" Price Display', 'printlay-woocommerce'); ?></strong>
                        </label>
                    </p>
                    <p>
                        <input type="number" name="_printlay_from_price" id="_printlay_from_price"
                               value="<?php echo esc_attr($from_price); ?>"
                               step="0.01" min="0" style="width:100%;"
                               placeholder="e.g. 5.00" />
                        <span class="description"><?php esc_html_e('Shown on product page and in Google (e.g. "From £5.00"). Actual price is calculated in the designer.', 'printlay-woocommerce'); ?></span>
                    </p>
                    <?php if ($product_id && $host): ?>
                    <p>
                        <a href="<?php echo esc_url($host . '/app/widget/products'); ?>" target="_blank" class="button button-small">
                            <?php esc_html_e('View in PrintLay', 'printlay-woocommerce'); ?> &rarr;
                        </a>
                    </p>
                    <?php endif; ?>
                </div>
            <?php endif; ?>
        </div>

        <script>
        jQuery(function($) {
            var $check = $('input[name="_printlay_enabled"]');
            var $fields = $('#printlay-product-fields');
            var $select = $('#_printlay_product_id');
            var currentVal = '<?php echo esc_js($product_id); ?>';

            $check.on('change', function() {
                $fields.toggle(this.checked);
            });

            if ($check.is(':checked') || currentVal) {
                $.post(ajaxurl, {
                    action: 'printlay_fetch_products',
                    _wpnonce: '<?php echo wp_create_nonce('printlay_products'); ?>'
                }, function(res) {
                    $select.empty();
                    if (res.success && res.data.length) {
                        $select.append('<option value=""><?php esc_html_e('— Select a product —', 'printlay-woocommerce'); ?></option>');
                        $.each(res.data, function(i, p) {
                            var sel = (p.id === currentVal) ? ' selected' : '';
                            $select.append('<option value="' + p.id + '"' + sel + '>' + p.name + ' (' + p.designer + ')</option>');
                        });
                    } else {
                        $select.append('<option value=""><?php esc_html_e('— No products found —', 'printlay-woocommerce'); ?></option>');
                    }
                });
            }
        });
        </script>
        <?php
    }

    public function save_meta(int $post_id, \WP_Post $post): void {
        if (!isset($_POST['_printlay_nonce']) || !wp_verify_nonce($_POST['_printlay_nonce'], 'printlay_save_meta')) {
            return;
        }
        if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) {
            return;
        }
        if (!current_user_can('edit_post', $post_id)) {
            return;
        }

        $enabled = isset($_POST['_printlay_enabled']) ? 'yes' : 'no';
        update_post_meta($post_id, '_printlay_enabled', $enabled);

        $product_id = sanitize_text_field($_POST['_printlay_product_id'] ?? '');
        update_post_meta($post_id, '_printlay_product_id', $product_id);

        $from_price = floatval($_POST['_printlay_from_price'] ?? 0);
        update_post_meta($post_id, '_printlay_from_price', $from_price > 0 ? $from_price : '');
    }

    public function ajax_fetch_products(): void {
        check_ajax_referer('printlay_products', '_wpnonce');
        if (!current_user_can('edit_products')) {
            wp_send_json_error('Permission denied');
        }

        $api = new PrintLay_API();
        $products = $api->list_products();

        if (is_wp_error($products)) {
            wp_send_json_error($products->get_error_message());
        }

        wp_send_json_success($products);
    }
}
